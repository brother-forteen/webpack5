/**
 * @createDate: 2021/3/16
 * @author: wen_dell
 * @email: wendell.chen@chinaentropy.com
 * **/
module.exports = {
    plugins: [
        require('postcss-preset-env')
    ]
};
