/**
 * @createDate: 2021/3/8
 * @author: wen_dell
 * @email: wendell.chen@chinaentropy.com
 * **/

'use strict';

import React from 'react';
import ReactDom from 'react-dom';
